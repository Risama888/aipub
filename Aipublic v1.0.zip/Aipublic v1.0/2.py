import requests
import pandas as pd
import numpy as np
import sqlite3
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report
import ta

# Fungsi untuk mengambil data 5 menit dari Binance
def fetch_binance_klines(symbol='BTCUSDT', interval='5m', limit=500):
    url = f'https://api.binance.com/api/v3/klines'
    params = {
        'symbol': symbol,
        'interval': interval,
        'limit': limit
    }
    response = requests.get(url, params=params)
    data = response.json()

    df = pd.DataFrame(data, columns=[
        'open_time', 'open', 'high', 'low', 'close', 'volume',
        'close_time', 'quote_asset_volume', 'number_of_trades',
        'taker_buy_volume', 'taker_buy_quote_volume', 'ignore'
    ])

    df['open_time'] = pd.to_datetime(df['open_time'], unit='ms')
    df.set_index('open_time', inplace=True)

    # Ubah kolom ke tipe numerik
    for col in ['open', 'high', 'low', 'close', 'volume']:
        df[col] = pd.to_numeric(df[col])

    return df

# Hitung SuperTrend
def compute_supertrend(df, period=20, multiplier=6):
    atr = ta.volatility.AverageTrueRange(high=df['high'], low=df['low'], close=df['close'], window=period).average_true_range()
    hl2 = (df['high'] + df['low']) / 2
    upperband = hl2 + (multiplier * atr)
    lowerband = hl2 - (multiplier * atr)

    supertrend = [True] * len(df)
    for i in range(1, len(df)):
        curr_close = df['close'].iloc[i]
        prev_supertrend = supertrend[i-1]
        prev_upperband = upperband.iloc[i-1]
        prev_lowerband = lowerband.iloc[i-1]
        if curr_close > prev_upperband:
            supertrend[i] = True
        elif curr_close < prev_lowerband:
            supertrend[i] = False
        else:
            supertrend[i] = prev_supertrend

        # Adjust bands
        if supertrend[i]:
            lowerband.iloc[i] = max(lowerband.iloc[i], lowerband.iloc[i-1])
        else:
            upperband.iloc[i] = min(upperband.iloc[i], upperband.iloc[i-1])

    df['SuperTrend'] = supertrend
    df['SuperTrend_signal'] = 1
    df.loc[df['SuperTrend'] == False, 'SuperTrend_signal'] = 0
    return df

# Hitung Trailing Stop
def compute_trailing_stop(df, window=5):
    df['Trailing_Stop'] = df['close'].rolling(window=window).min()
    df['Training_Stop_Signal'] = 0
    df.loc[df['close'] < df['Trailing_Stop'], 'Training_Stop_Signal'] = -1  # Jual
    df.loc[df['close'] > df['Trailing_Stop'], 'Training_Stop_Signal'] = 1   # Beli
    return df

# Fungsi untuk menghitung level TP dan SL
def compute_trade_levels(entry_price, direction):
    if direction == 1:
        tp1 = entry_price * (1 + 0.005)
        tp2 = entry_price * (1 + 0.01)
        tp3 = entry_price * (1 + 0.015)
        sl = entry_price * (1 - 0.01)
    else:
        tp1 = entry_price * (1 - 0.005)
        tp2 = entry_price * (1 - 0.01)
        tp3 = entry_price * (1 - 0.015)
        sl = entry_price * (1 + 0.01)
    return {'TP1': tp1, 'TP2': tp2, 'TP3': tp3, 'SL': sl}

# Fungsi untuk inisialisasi database
def init_db(db_name='database.db'):
    conn = sqlite3.connect(db_name)
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS signals (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT,
            signal TEXT,
            entry_price REAL,
            TP1 REAL,
            TP2 REAL,
            TP3 REAL,
            SL REAL
        )
    ''')
    conn.commit()
    return conn

# Fungsi untuk mendapatkan sinyal terakhir dari database
def get_last_signal(conn):
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM signals ORDER BY id DESC LIMIT 1')
    return cursor.fetchone()

# Fungsi untuk menghapus semua sinyal di database
def clear_signals(conn):
    cursor = conn.cursor()
    cursor.execute('DELETE FROM signals')
    conn.commit()

# Fungsi untuk menyimpan sinyal ke database
def save_signal(conn, timestamp, signal, entry_price, levels):
    cursor = conn.cursor()
    cursor.execute('''
        INSERT INTO signals (timestamp, signal, entry_price, TP1, TP2, TP3, SL)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ''', (
        timestamp,
        signal,
        entry_price,
        levels['TP1'],
        levels['TP2'],
        levels['TP3'],
        levels['SL']
    ))
    conn.commit()

# Main proses
df = fetch_binance_klines()

# Hitung indikator
df = compute_supertrend(df)
df = compute_trailing_stop(df)

# Buat fitur dan target
df['return'] = df['close'].pct_change()
df['supertrend'] = df['SuperTrend'].astype(int)
df['training_stop'] = df['Training_Stop_Signal']

# Drop missing values
df.dropna(inplace=True)

# Fitur dan target
X = df[['return', 'supertrend', 'training_stop']]
y = df['SuperTrend_signal']

# Split data
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, shuffle=False)

# Latih model
clf = RandomForestClassifier(n_estimators=100, random_state=42)
clf.fit(X_train, y_train)

# Prediksi
y_pred = clf.predict(X_test)

# Evaluasi
print(classification_report(y_test, y_pred))

# Inisialisasi database
conn = init_db()

# Prediksi sinyal terbaru
latest_features = X.iloc[-1].values.reshape(1, -1)
predicted_signal = clf.predict(latest_features)[0]

# Pengecekan posisi terakhir dan pengelolaan sinyal
last_signal_record = get_last_signal(conn)
last_signal = last_signal_record[2] if last_signal_record else None  # kolom 'signal' adalah indeks 2

# Jika posisi terakhir sama dengan sinyal baru, tidak perlu hapus
if last_signal == str(predicted_signal):
    print(f"Posisi terakhir ({last_signal}) sama dengan sinyal baru. Tidak ada perubahan.")
else:
    # Kalau berbeda, hapus semua sinyal lama dan simpan yang baru
    print(f"Posisi terakhir: {last_signal}. Mengganti dengan sinyal baru: {predicted_signal}.")
    clear_signals(conn)
    # Tentukan level TP/SL berdasarkan sinyal
    entry_price = df['close'].iloc[-1]
    levels = compute_trade_levels(entry_price, predicted_signal)
    print(f"Entry Price: {entry_price:.2f}")
    print(f"TP1 (0.5%): {levels['TP1']:.2f}")
    print(f"TP2 (1%): {levels['TP2']:.2f}")
    print(f"TP3 (1.5%): {levels['TP3']:.2f}")
    print(f"Stop Loss (1%): {levels['SL']:.2f}")
    # Simpan ke database
    timestamp = df.index[-1].strftime('%Y-%m-%d %H:%M:%S')
    save_signal(conn, timestamp, str(predicted_signal), entry_price, levels)

# Tutup koneksi
conn.close()