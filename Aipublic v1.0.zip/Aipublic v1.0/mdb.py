import sqlite3

# Membuka koneksi ke database
conn = sqlite3.connect('database.db')

# Membuat cursor
cursor = conn.cursor()

# Menampilkan semua data dari tabel 'pegawai'
cursor.execute("SELECT * FROM signals")
rows = cursor.fetchall()

# Menampilkan hasilnya
if rows:
    print("Isi tabel 'signals':")
    for row in rows:
        print(row)
else:
    print("Tabel 'signals' kosong atau tidak ada data.")

# Menutup koneksi
conn.close()