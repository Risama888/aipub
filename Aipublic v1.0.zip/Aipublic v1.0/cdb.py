import sqlite3

def create_database_and_table(db_name='database.db'):
    # Membuka koneksi ke database (akan membuat file jika belum ada)
    conn = sqlite3.connect(db_name)
    cursor = conn.cursor()

    # Membuat tabel jika belum ada
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS signals (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT,
            signal TEXT,
            entry_price REAL,
            TP1 REAL,
            TP2 REAL,
            TP3 REAL,
            SL REAL
        )
    ''')

    # Commit dan tutup koneksi
    conn.commit()
    conn.close()

# Panggil fungsi untuk membuat database dan tabel
create_database_and_table()