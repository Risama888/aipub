import requests
import pandas as pd
import numpy as np
import time
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
import ta

# Variabel global untuk posisi aktif
current_position = None

def stop_position():
    global current_position
    if current_position:
        print(f"Menutup posisi {current_position} karena sinyal berlawanan atau error.")
        # Tambahkan kode eksekusi order untuk menutup posisi sesuai API trading
        current_position = None

def start_position(position_type, entry_price, levels):
    global current_position
    if current_position and current_position != position_type:
        stop_position()
    current_position = position_type
    print(f"Memulai posisi {position_type} dengan entry {entry_price:.2f}")
    # Monitoring posisi
    monitor_and_close(position_type, entry_price, levels)

def monitor_and_close(position_type, entry_price, levels, check_interval=5):
    tp1 = levels['TP1']
    sl = levels['SL']
    print(f"Monitoring posisi {position_type}...")
    while True:
        try:
            current_price = get_latest_price()
            print(f"Harga saat ini: {current_price:.2f}")
            if position_type == 'buy':
                if current_price >= tp1:
                    print("Harga mencapai TP1 (0.5%), menutup posisi buy.")
                    break
                elif current_price <= sl:
                    print("Harga mencapai SL (1%), menutup posisi buy.")
                    break
            elif position_type == 'sell':
                if current_price <= tp1:
                    print("Harga mencapai TP1 (0.5%), menutup posisi sell.")
                    break
                elif current_price >= sl:
                    print("Harga mencapai SL (1%), menutup posisi sell.")
                    break
            time.sleep(check_interval)
        except Exception as e:
            print(f"Terjadi error saat monitoring: {e}. Mengulangi...")
            time.sleep(check_interval)
    # Setelah posisi ditutup, reset posisi
    stop_position()

def get_latest_price(symbol='BTCUSDT'):
    url = f'https://api.binance.com/api/v3/ticker/price?symbol={symbol}'
    response = requests.get(url)
    data = response.json()
    return float(data['price'])

def fetch_binance_klines(symbol='BTCUSDT', interval='5m', limit=500):
    url = 'https://api.binance.com/api/v3/klines'
    params = {'symbol': symbol, 'interval': interval, 'limit': limit}
    response = requests.get(url, params=params)
    data = response.json()
    df = pd.DataFrame(data, columns=[
        'open_time', 'open', 'high', 'low', 'close', 'volume',
        'close_time', 'quote_asset_volume', 'number_of_trades',
        'taker_buy_volume', 'taker_buy_quote_volume', 'ignore'
    ])
    df['open_time'] = pd.to_datetime(df['open_time'], unit='ms')
    df.set_index('open_time', inplace=True)
    for col in ['open', 'high', 'low', 'close', 'volume']:
        df[col] = pd.to_numeric(df[col])
    return df

def compute_supertrend(df, period=20, multiplier=6):
    atr = ta.volatility.AverageTrueRange(high=df['high'], low=df['low'], close=df['close'], window=period).average_true_range()
    hl2 = (df['high'] + df['low']) / 2
    upperband = hl2 + (multiplier * atr)
    lowerband = hl2 - (multiplier * atr)
    supertrend = [True] * len(df)
    for i in range(1, len(df)):
        curr_close = df['close'].iloc[i]
        prev_supertrend = supertrend[i-1]
        prev_upperband = upperband.iloc[i-1]
        prev_lowerband = lowerband.iloc[i-1]
        if curr_close > prev_upperband:
            supertrend[i] = True
        elif curr_close < prev_lowerband:
            supertrend[i] = False
        else:
            supertrend[i] = prev_supertrend
        if supertrend[i]:
            lowerband.iloc[i] = max(lowerband.iloc[i], lowerband.iloc[i-1])
        else:
            upperband.iloc[i] = min(upperband.iloc[i], upperband.iloc[i-1])
    df['SuperTrend'] = supertrend
    df['SuperTrend_signal'] = 1
    df.loc[df['SuperTrend'] == False, 'SuperTrend_signal'] = 0
    return df

def compute_trailing_stop(df, window=5):
    df['Trailing_Stop'] = df['close'].rolling(window=window).min()
    df['Training_Stop_Signal'] = 0
    df.loc[df['close'] < df['Trailing_Stop'], 'Training_Stop_Signal'] = -1
    df.loc[df['close'] > df['Trailing_Stop'], 'Training_Stop_Signal'] = 1
    return df

def compute_trade_levels(entry_price, direction):
    if direction == 1:
        tp1 = entry_price * (1 + 0.005)
        tp2 = entry_price * (1 + 0.01)
        tp3 = entry_price * (1 + 0.015)
        sl = entry_price * (1 - 0.01)
    else:
        tp1 = entry_price * (1 - 0.005)
        tp2 = entry_price * (1 - 0.01)
        tp3 = entry_price * (1 - 0.015)
        sl = entry_price * (1 + 0.01)
    return {'TP1': tp1, 'TP2': tp2, 'TP3': tp3, 'SL': sl}

if __name__ == "__main__":
    while True:
        try:
            print("\n=== Memulai siklus baru ===")
            # Fetch data dan hitung indikator
            df = fetch_binance_klines()
            df = compute_supertrend(df)
            df = compute_trailing_stop(df)

            # Buat fitur dan target
            df['return'] = df['close'].pct_change()
            df['supertrend'] = df['SuperTrend'].astype(int)
            df['training_stop'] = df['Training_Stop_Signal']
            df.dropna(inplace=True)

            X = df[['return', 'supertrend', 'training_stop']]
            y = df['SuperTrend_signal']

            # Train model
            X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, shuffle=False)
            clf = RandomForestClassifier(n_estimators=100, random_state=42)
            clf.fit(X_train, y_train)

            # Prediksi terakhir
            latest_features = X.iloc[-1].values.reshape(1, -1)
            predicted_signal = clf.predict(latest_features)[0]

            if predicted_signal == 1:
                print("Sinyal Beli (Buy)")
                entry_price = df['close'].iloc[-1]
                levels = compute_trade_levels(entry_price, direction=1)
                print(f"Entry Price: {entry_price:.2f}")
                print(f"TP1 (0.5%): {levels['TP1']:.2f}")
                print(f"TP2 (1%): {levels['TP2']:.2f}")
                print(f"TP3 (1.5%): {levels['TP3']:.2f}")
                print(f"Stop Loss (1%): {levels['SL']:.2f}")
                start_position('buy', entry_price, levels)

            elif predicted_signal == 0:
                print("Sinyal Jual (Sell)")
                entry_price = df['close'].iloc[-1]
                levels = compute_trade_levels(entry_price, direction=0)
                print(f"Entry Price: {entry_price:.2f}")
                print(f"TP1 (0.5%): {levels['TP1']:.2f}")
                print(f"TP2 (1%): {levels['TP2']:.2f}")
                print(f"TP3 (1.5%): {levels['TP3']:.2f}")
                print(f"Stop Loss (1%): {levels['SL']:.2f}")
                start_position('sell', entry_price, levels)

            print("Siklus selesai. Tunggu beberapa saat sebelum siklus berikutnya...")
            time.sleep(30)  # Jeda antar siklus, sesuaikan kebutuhan

        except Exception as e:
            print(f"Error utama: {e}. Mengulang siklus...")
            time.sleep(30)  # Jeda sebelum mengulang kembali